<?php
    $to      = 'yashvanth4510@gmail.com';
    $subject = 'the subject';
    $message = 'hello';
    $headers = 'From:nallathimbi@gmail.com'       . "\r\n" .
                 'Reply-To: webmaster@example.com' . "\r\n" .
                 'X-Mailer: PHP/' . phpversion();

              ?>
    